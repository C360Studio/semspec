# OSH MAVSDK Driver

Driver for integrating [MAVLink](https://mavlink.io/) /
[MAVSDK](https://mavsdk.mavlink.io/) autopilot telemetry and control with
[OpenSensorHub](https://opensensorhub.org/) via the OGC Connected Systems
API.

## Project structure

This repository is the foundational Gradle fixture for an OpenSensorHub (OSH)
MAVSDK driver. The source tree is intentionally small so driver implementation
work can add OSH modules, MAVSDK adapters, raw MAVLink helpers, and tests in the
standard Java locations without changing the build layout.

```text
.
├── build.gradle                 # Java 17 build, repositories, and dependencies
├── settings.gradle              # Root project name: osh-driver-mavsdk
├── gradlew / gradlew.bat        # Checked-in Gradle wrapper entry points
├── gradle/                      # Gradle wrapper metadata
├── src/main/java/               # Production driver code belongs here
└── src/test/java/               # Unit and integration tests belong here
```

Expected implementation layering:

- OSH driver/module classes live under `src/main/java` and expose telemetry and
  command surfaces through OpenSensorHub and Connected Systems API types.
- MAVSDK integration code owns the managed connection to a MAVSDK server or
  MAVLink endpoint and maps telemetry/action plugin events into OSH data and
  control flows.
- Raw MAVLink compatibility code owns low-level frame parsing and serialization
  for cases that need direct MAVLink access instead of MAVSDK plugin
  abstractions.
- Tests live next to the Java test tree in `src/test/java`, using JUnit 5 from
  the Gradle configuration.

## Included dependencies

The root `build.gradle` declares the dependency set needed by the initial driver
architecture:

| Dependency | Coordinate | Role |
| --- | --- | --- |
| OpenSensorHub core | `com.github.opensensorhub.osh-core:sensorhub-core:v2.0-beta1` | Base OSH runtime and sensor module APIs used by the driver. |
| OpenSensorHub SWE/CS API service | `com.github.opensensorhub.osh-core:sensorhub-service-sweapi:v2.0-beta1` | Connected Systems / SensorWeb API integration surface for exposed observations and controls. |
| MAVSDK-Java | `io.mavsdk:mavsdk:3.14.0` | High-level autopilot connection, telemetry, and action plugin client used for PX4 SITL smoke coverage and production MAVSDK operation. |
| MAVLink Java | `io.dronefleet.mavlink:mavlink:1.1.11` | MAVLink message model used by the direct compatibility path. |
| MAVLink protocol | `io.dronefleet.mavlink:mavlink-protocol:1.1.11` | MAVLink frame reader/writer support for raw packet decoding and serialization. |
| JUnit Jupiter | `org.junit.jupiter:junit-jupiter:5.10.2` | Java test framework used by `./gradlew test`. |

OpenSensorHub artifacts are resolved from JitPack because anonymous OSH 2.x
artifacts are not available from Maven Central. MAVSDK-Java, MAVLink, and JUnit
resolve from Maven Central.

## Build and test instructions

Use the checked-in Gradle wrapper from the repository root:

```sh
./gradlew dependencies --quiet
./gradlew test
```

The dependency check verifies that all declared coordinates and repositories are
resolvable. The test task compiles main/test sources and runs the JUnit 5 suite.
Both commands are required gates for changes to this repository.

Useful Gradle commands during development:

```sh
./gradlew clean test          # Rebuild and run the full test suite
./gradlew test --info         # Run tests with additional Gradle diagnostics
./gradlew dependencies        # Inspect resolved dependency graphs
```

The project targets Java 17 for both source and bytecode compatibility, matching
the OSH core baseline used by the driver.

## PX4 SITL MAVSDK smoke support

The project structure is prepared for the `mavlink.px4-sitl.mavsdk-smoke`
harness profile. That profile supplies a PX4 SITL service exposing MAVLink over
UDP, with evidence anchors such as `px4io/px4-sitl`, UDP port `14540`,
`mavsdk_core_connected`, and `HEARTBEAT`.

Driver integration tests for that profile should:

1. Read the SITL MAVLink endpoint from the qa-runner-provided environment rather
   than hard-coding `localhost` or a fixed port.
2. Connect through MAVSDK-Java and wait for the MAVSDK core connection state to
   report a connected system before invoking plugins.
3. Assert that a live `HEARTBEAT` is observed from PX4 SITL.
4. Exercise at least one telemetry/data-stream path and one control/action path,
   gating commands on vehicle health and connection readiness.
5. Verify telemetry is mapped into OSH / Connected Systems API observations so
   downstream clients can consume vehicle state through driver data streams.

This keeps the MAVSDK path responsible for high-level autopilot behavior while
OSH-facing code remains focused on module registration, observation publication,
and command/control exposure.

## Direct MAVLink compatibility support

The `mavlink.raw-mavlink-direct` compatibility profile is supported by the
MAVLink Java dependencies. This path is intended for low-level tests and fallback
features that need to parse or emit MAVLink frames without relying exclusively on
MAVSDK plugin abstractions.

Raw MAVLink tests should use captured frames or an in-process peer and verify
behavior such as:

- decoding a real MAVLink `HEARTBEAT` frame;
- serializing command frames with the MAVLink protocol writer;
- parsing the expected acknowledgement or parser result, such as `COMMAND_ACK`;
- keeping parser/serializer logic separate from OSH publication side effects so
  unit tests can cover frame handling deterministically.

## Upstream reference material

The driver implements OpenSensorHub's Connected Systems API on top of MAVSDK
Java. When the EPIC overlay is active, use the mounted upstream sources as the
primary reference points:

- OSH addons, including the baseline MAVSDK driver:
  `/sources/github-com-opensensorhub-osh-addons`
- MAVSDK Java library: `/sources/github-com-mavlink-MAVSDK-Java`
- OSH core Gradle multi-module: `/sources/github-com-opensensorhub-osh-core`
- OGC Connected Systems API spec:
  `/sources/github-com-opengeospatial-ogcapi-connected-systems`

When `/sources/` is not mounted, use current upstream project documentation and
source repositories before changing dependency coordinates or public API usage.
