# OSH MAVSDK Driver

Driver for integrating [MAVLink](https://mavlink.io/) /
[MAVSDK](https://mavsdk.mavlink.io/) autopilot telemetry and control with
[OpenSensorHub](https://opensensorhub.org/) via the OGC Connected Systems
API.

## Build system

Gradle. OSH itself uses Gradle (`build.gradle`, `common.gradle`,
`release.gradle`); a Maven-based driver fixture would force the agent to
translate Gradle conventions to Maven, which doesn't reflect real OSH
driver development. Java 17, matching `osh-core`'s `sourceCompatibility`.

## Baseline (the prompt's starting point)

The upstream reference implementation lives at
`opensensorhub/osh-addons/sensors/robotics/sensorhub-driver-mavsdk`. The
`@mavlink-hard` Playwright spec instructs the agent to treat that addon
as the baseline — preserve its OSH sensor module patterns, MAVSDK Java
integration, mavsdk_server lifecycle, telemetry outputs, and control
inputs unless the architecture explicitly replaces them.

## Reference material

The driver implements OpenSensorHub's Connected Systems API on top of
MAVSDK Java. The agent reads upstream sources directly when the EPIC
overlay is active:

- OSH addons (includes the baseline MAVSDK driver): `/sources/github-com-opensensorhub-osh-addons`
- MAVSDK Java library: `/sources/github-com-mavlink-MAVSDK-Java`
- OSH core (Gradle multi-module): `/sources/github-com-opensensorhub-osh-core`
- OGC Connected Systems API spec: `/sources/github-com-opengeospatial-ogcapi-connected-systems`

When `/sources/` is not mounted, fall back to `web_search` +
`http_request` against the canonical GitHub raw URLs. Cite specific
values (a version, a class signature, a config snippet) in the
implementation; do not paste large blocks of upstream source.

## Building

```sh
./gradlew dependencies   # resolve declared deps (the structural-validator
                         # gradle-dependencies check)
./gradlew test           # compile + run JUnit 5 tests
```

The `build.gradle` ships with `repositories` and `dependencies` blocks
intentionally left as TODOs — those are the agent's first task,
informed by reading the upstream `sensorhub-driver-mavsdk/build.gradle`
and the OSH + MAVSDK release configurations.

## Harness profiles

The `mavlink.px4-sitl.mavsdk-smoke` profile in
`workflow/harnesscatalog/catalog/mavlink.yaml` provides a live PX4 SITL
+ mavsdk_server qa-runner service. The architect selects it for the
required smoke acceptance test; the raw `mavlink.raw-mavlink-direct`
compatibility profile covers the generic-MAVLink path.

## MAVSDK plugins and raw MAVLink fallback

The driver prefers typed MAVSDK Java plugins for behavior that MAVSDK
models explicitly. Typed plugins provide stable Java APIs, normalized
units, connection-state semantics, and plugin-specific health checks that
are easier to expose through Connected Systems API resources. This path is
the default for telemetry and operator commands that are already covered
by MAVSDK plugins.

Raw MAVLink remains a compatibility fallback for messages or commands that
MAVSDK does not expose, for dialect-specific extensions, and for diagnostic
coverage where preserving the original MAVLink frame is more important
than a typed abstraction. The fallback keeps the driver from being blocked
by MAVSDK plugin coverage, but it also moves more responsibility into the
driver: message parsing, command acknowledgements, unit normalization,
retry bounds, and error mapping must be handled locally.

Use the following rule of thumb:

- Use a typed MAVSDK plugin when the plugin exposes the required vehicle
  state or command and the CS API mapping can be expressed without losing
  required semantics.
- Use raw MAVLink fallback when MAVSDK has no typed surface for the message
  or command, when a vehicle-specific dialect must be preserved, or when a
  diagnostic stream needs byte-level evidence.
- Mark a mapping as `Deferred` until the driver has a tested runtime path
  and a CS API representation with a documented rationale.

### MAVSDK to Connected Systems API coverage matrix

The table below is intentionally machine-checkable: every row has a plugin,
MAVLink evidence, CS API type, runtime mapping, and rationale. `Deferred`
means the mapping is not part of the current runtime contract.

| MAVSDK plugin | MAVLink evidence handled | CS API type | Runtime mapping | Rationale |
| --- | --- | --- | --- | --- |
| Telemetry | `HEARTBEAT` | SystemEvent | Runtime | Vehicle connection and liveness state are emitted as system events so clients can observe autopilot availability without parsing raw MAVLink. |
| Telemetry | `GLOBAL_POSITION_INT` | Observation | Runtime | Position and altitude telemetry are normalized through the typed telemetry path and exposed as CS API observations/data streams. |
| Action | `MAV_CMD_COMPONENT_ARM_DISARM` | ControlStream | Runtime | Arm/disarm is an operator command with MAVSDK action support, so it maps to a CS API control stream instead of raw command injection. |
| Action | `MAV_CMD_NAV_TAKEOFF` | ControlStream | Deferred | Takeoff belongs on the action control surface, but runtime execution is gated until health checks, altitude validation, and SITL acceptance coverage are present. |
| Mission | `MISSION_ITEM_INT` / mission upload protocol | Deferred | Deferred | Mission planning needs multi-message transaction handling and CS API task semantics that are not part of the current telemetry/control contract. |
| Offboard | `SET_POSITION_TARGET_LOCAL_NED` | Deferred | Deferred | Offboard setpoints require high-rate streaming, watchdog behavior, and explicit safety ownership before they can be exposed as controls. |
| Gimbal | `MAV_CMD_DO_MOUNT_CONTROL` | Deferred | Deferred | Gimbal support is vehicle- and payload-dependent, so the driver defers it until payload capability discovery is implemented. |
| Raw MAVLink fallback | Unmodeled or dialect-specific MAVLink frames | Observation / ControlStream / SystemEvent | Fallback | Frames without typed MAVSDK coverage are decoded locally and mapped only when the driver can preserve semantics, validate inputs, and bound retries. |
