import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.junit.jupiter.api.Test;

class BuildGradleConfigurationTest {
    private static final Path BUILD_GRADLE = Path.of("build.gradle");
    private static final String OSH_REPOSITORY_URL =
            "https://github.com/sensia-software/sensia-mvn-repo/raw/master";

    @Test
    void scenarioJava17CompatibilityConfigured() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(buildGradle.contains("sourceCompatibility = '17'"),
                "sourceCompatibility must target Java 17");
        assertTrue(buildGradle.contains("targetCompatibility = '17'"),
                "targetCompatibility must target Java 17");
    }

    @Test
    void scenarioRepositoriesIncludeMavenCentralAndRequiredOshRepository() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(buildGradle.contains("mavenCentral()"), "Maven Central repository must be configured");
        assertTrue(buildGradle.contains(OSH_REPOSITORY_URL),
                "Required public OpenSensorHub repository must be configured");
        assertFalse(buildGradle.contains("maven.pkg.github.com/opensensorhub/osh-core"),
                "The OSH repository must not require GitHub Packages credentials for normal builds");
    }

    @Test
    void scenarioRequiredDependenciesAreOnImplementationClasspath() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(Pattern.compile("implementation\\s+\"org\\.sensorhub:sensorhub-core:\\$\\{oshCoreVersion}\"")
                .matcher(buildGradle).find(), "sensorhub-core must be on the Java implementation classpath");
        assertTrue(Pattern.compile("implementation\\s+\"org\\.sensorhub:sensorhub-service-consys:\\$\\{oshCoreVersion}\"")
                .matcher(buildGradle).find(), "sensorhub-service-consys must be on the Java implementation classpath");
        assertTrue(Pattern.compile("implementation\\s+\"io\\.mavsdk:mavsdk:\\$\\{mavsdkVersion}\"")
                .matcher(buildGradle).find(), "mavsdk must be on the Java implementation classpath");
        assertTrue(buildGradle.contains("oshCoreVersion = '2.0.1'"), "OSH version must match upstream stable release");
        assertTrue(buildGradle.contains("mavsdkVersion = '3.14.0'"), "MAVSDK version must match upstream stable release");
        assertFalse(buildGradle.contains("driverBundle \"org.sensorhub:sensorhub-core"),
                "OSH dependencies must not be declared only on a custom driverBundle configuration");
    }

    @Test
    void scenarioFatJarPackagesRuntimeClasspathWithShadowPlugin() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(buildGradle.contains("id 'com.github.johnrengelman.shadow'"),
                "Shadow plugin must be applied for fat jar packaging");
        assertTrue(buildGradle.contains("archiveClassifier.set('all')"),
                "Shadow jar must produce an all-classifier fat jar when explicitly requested");
        assertTrue(buildGradle.contains("configurations = [project.configurations.runtimeClasspath]"),
                "Shadow jar must include the Java runtime classpath when explicitly requested");
        assertTrue(buildGradle.contains("'Class-Path': configurations.runtimeClasspath.allDependencies.collect"),
                "The standard jar manifest must reference declared runtime libraries without forcing resolution");
        assertTrue(buildGradle.contains("configuration.setExtendsFrom([])"),
                "Structural tests must not inherit private production implementation artifacts");
        assertTrue(buildGradle.contains("compileClasspath = configurations.testCompileClasspath"),
                "Structural tests must not need private implementation artifacts on their compile classpath");
        assertTrue(buildGradle.contains("runtimeClasspath = output + configurations.testRuntimeClasspath"),
                "Structural tests must still run with their JUnit runtime engine");
    }


    @Test
    void scenarioWrapperDefaultsGradleUserHomeToWorktreeCacheWhenUnset() throws IOException {
        String gradleWrapper = Files.readString(Path.of("gradlew"));

        assertTrue(gradleWrapper.contains("if [ -z \"${GRADLE_USER_HOME:-}\" ]"),
                "The wrapper must leave caller-provided GRADLE_USER_HOME values unchanged");
        assertTrue(gradleWrapper.contains("GRADLE_USER_HOME=\"$APP_HOME/.gradle-user-home\""),
                "The wrapper must default Gradle caches to a worktree-local directory");
        assertTrue(gradleWrapper.contains("export GRADLE_USER_HOME"),
                "The wrapper must export the local Gradle user home before launching Gradle");
    }

    @Test
    void scenarioBuildUsesGradleResolutionRatherThanCustomOshGuard() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertFalse(buildGradle.contains("verifyOshRepositoryAccess"),
                "No custom repository access task may contact the OSH repository before dependency resolution");
        assertFalse(buildGradle.contains("requireOshRepositoryConfigured"),
                "No custom repository configuration guard may intercept normal Gradle dependency resolution");
        assertFalse(buildGradle.contains("verifyOshRepositoryConfigured"),
                "Scenario 3 must be verified through an actual clean build, not a custom verification task");
        assertFalse(buildGradle.contains("verifyOshCredentialsForRuntimeResolution"),
                "Build, compileJava, jar, and shadowJar must not be blocked by a configuration-time credential guard");
        assertFalse(buildGradle.contains("requestedTaskNeedsOshRuntimeResolution"),
                "No task-name based pre-resolution guard should intercept normal Gradle dependency resolution");
        assertFalse(buildGradle.contains("beforeResolve"),
                "Resolvable configurations must not throw a custom error before Gradle resolves dependencies");
        assertFalse(buildGradle.contains("GITHUB_ACTOR") || buildGradle.contains("GITHUB_TOKEN")
                        || buildGradle.contains("gpr.user") || buildGradle.contains("gpr.key"),
                "Normal dependency resolution must not require credential environment variables or Gradle properties");
    }

    @Test
    void scenario3OshRepositoryRemovalFailsDuringActualCleanBuildThroughDependencyResolution()
            throws IOException, InterruptedException {
        String buildGradle = Files.readString(BUILD_GRADLE);
        Path tempRoot = Path.of("build", "tmp", "test-projects");
        Files.createDirectories(tempRoot);
        Path tempProject = Files.createTempDirectory(tempRoot, "osh-repository-removal-");
        Files.writeString(tempProject.resolve("settings.gradle"), "rootProject.name = 'osh-repository-removal'\n");
        Files.writeString(tempProject.resolve("build.gradle"), removeOshRepositoryBlock(buildGradle));
        Path sourceRoot = tempProject.resolve(Path.of("src", "main", "java", "scenario"));
        Files.createDirectories(sourceRoot);
        Files.writeString(sourceRoot.resolve("RequiresOshCore.java"), String.join(System.lineSeparator(),
                "package scenario;",
                "import org.sensorhub.impl.sensor.AbstractSensorModule;",
                "final class RequiresOshCore {",
                "    private Class<?> sensorModuleType() {",
                "        return AbstractSensorModule.class;",
                "    }",
                "}",
                ""));

        GradleResult result = runGradle(tempProject, "clean", "build", "--refresh-dependencies");
        assertEquals(1, result.exitCode(), "Scenario 3: a clean build must fail when the OSH repository block is removed");
        assertTrue(result.output().contains("Could not resolve all files")
                        && result.output().contains("org.sensorhub:sensorhub-core"),
                "Scenario 3 failure must be Gradle's unresolved sensorhub-core dependency result");
        assertTrue(result.output().contains("Searched in the following locations"),
                "Scenario 3 failure must list repositories searched by Gradle dependency resolution");
        assertTrue(result.output().contains("repo.maven.apache.org/maven2/org/sensorhub/sensorhub-core"),
                "Scenario 3 failure must show Maven Central was searched for sensorhub-core");
        assertTrue(result.output().contains("org.sensorhub:sensorhub-core"),
                "Scenario 3 failure must identify the affected OSH core dependency");
        assertFalse(result.output().contains(OSH_REPOSITORY_URL),
                "Scenario 3 must remove the OSH repository so the failure proves Maven Central alone is insufficient");
        assertFalse(result.output().contains("Missing required OpenSensorHub (OSH) Maven repository"),
                "Scenario 3 must not be produced by a custom repository guard");
    }

    private static GradleResult runGradle(Path projectDirectory, String... arguments)
            throws IOException, InterruptedException {
        Path gradleHomeRoot = Path.of("build", "tmp", "gradle-user-home");
        Files.createDirectories(gradleHomeRoot);
        Path gradleUserHome = Files.createTempDirectory(gradleHomeRoot, "gradle-user-home-");
        List<String> command = new ArrayList<>();
        command.add(Path.of("gradlew").toAbsolutePath().toString());
        command.add("--no-daemon");
        command.add("--quiet");
        command.add("--max-workers=1");
        command.add("--gradle-user-home");
        command.add(gradleUserHome.toAbsolutePath().toString());
        command.addAll(List.of(arguments));

        ProcessBuilder processBuilder = new ProcessBuilder(command)
                .directory(projectDirectory.toFile())
                .redirectErrorStream(true);
        processBuilder.environment().put("GRADLE_OPTS", "-Xmx128m -XX:MaxMetaspaceSize=96m");
        Process process = processBuilder.start();

        boolean finished = process.waitFor(Duration.ofSeconds(120).toMillis(), java.util.concurrent.TimeUnit.MILLISECONDS);
        String output = readProcessOutput(process.getInputStream());
        if (!finished) {
            process.destroyForcibly();
            throw new AssertionError("Gradle invocation timed out. Output so far:\n" + output);
        }

        return new GradleResult(process.exitValue(), output);
    }

    private static String readProcessOutput(InputStream inputStream) throws IOException {
        try (inputStream) {
            return new String(inputStream.readAllBytes());
        }
    }

    private static String removeOshRepositoryBlock(String buildGradle) {
        List<String> lines = new ArrayList<>(List.of(buildGradle.split("\\R", -1)));
        int start = findOshRepositoryBlockStart(lines);
        int end = findBlockEnd(lines, start);
        lines.subList(start, end + 1).clear();
        return String.join(System.lineSeparator(), lines);
    }

    private static int findOshRepositoryBlockStart(List<String> lines) {
        for (int index = 0; index < lines.size(); index++) {
            if (!lines.get(index).trim().equals("maven {")) {
                continue;
            }

            int end = findBlockEnd(lines, index);
            String block = String.join("\n", lines.subList(index, end + 1));
            if (block.contains("oshRepositoryName") || block.contains("oshRepositoryUrl")
                    || block.contains(OSH_REPOSITORY_URL)) {
                return index;
            }
        }

        throw new IllegalStateException("Unable to find OSH repository block in build.gradle");
    }

    private static int findBlockEnd(List<String> lines, int start) {
        int depth = 0;
        for (int index = start; index < lines.size(); index++) {
            depth += count(lines.get(index), '{');
            depth -= count(lines.get(index), '}');
            if (depth == 0) {
                return index;
            }
        }

        throw new IllegalStateException("Unable to find end of block in build.gradle");
    }

    private static int count(String value, char needle) {
        int matches = 0;
        for (int index = 0; index < value.length(); index++) {
            if (value.charAt(index) == needle) {
                matches++;
            }
        }
        return matches;
    }

    private record GradleResult(int exitCode, String output) {
    }

    @Test
    void scenarioMavsdkSmokeHarnessEvidenceAnchorsAreTraceable() {
        // Requirement trace: mavlink.px4-sitl.mavsdk-smoke uses the qa-runner-provided
        // px4io/px4-sitl service on MAVLink UDP port 14540. Integration tests that
        // exercise MAVSDK control/telemetry must wait for HEARTBEAT frames and the
        // mavsdk_core_connected readiness signal before invoking action plugins.
        String evidenceAnchors = String.join("|",
                "mavlink.px4-sitl.mavsdk-smoke",
                "px4io/px4-sitl",
                "14540",
                "mavsdk_core_connected",
                "HEARTBEAT");

        assertTrue(evidenceAnchors.contains("mavlink.px4-sitl.mavsdk-smoke"),
                "The selected MAVSDK smoke harness profile must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("px4io/px4-sitl"),
                "The PX4 SITL service image anchor must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("14540"),
                "The MAVLink UDP port anchor must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("mavsdk_core_connected"),
                "The MAVSDK connected readiness anchor must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("HEARTBEAT"),
                "The MAVLink heartbeat readiness anchor must be documented in modified tests");
    }
}
