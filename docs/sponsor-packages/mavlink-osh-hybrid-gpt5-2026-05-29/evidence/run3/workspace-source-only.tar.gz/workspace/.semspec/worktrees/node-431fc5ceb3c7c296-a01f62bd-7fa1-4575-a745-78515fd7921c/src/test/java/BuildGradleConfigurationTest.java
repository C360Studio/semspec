import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.junit.jupiter.api.Test;

class BuildGradleConfigurationTest {
    private static final Path BUILD_GRADLE = Path.of("build.gradle");

    @Test
    void scenarioJava17CompatibilityConfigured() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(buildGradle.contains("sourceCompatibility = JavaVersion.VERSION_17"),
                "sourceCompatibility must target Java 17");
        assertTrue(buildGradle.contains("targetCompatibility = JavaVersion.VERSION_17"),
                "targetCompatibility must target Java 17");
    }

    @Test
    void scenarioRepositoriesIncludeMavenCentralAndRequiredOshRepository() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(buildGradle.contains("mavenCentral()"), "Maven Central repository must be configured");
        assertTrue(buildGradle.contains("https://maven.pkg.github.com/opensensorhub/osh-core"),
                "Required OSH GitHub Packages repository must be configured");
    }

    @Test
    void scenarioRequiredDependenciesAreOnImplementationClasspath() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(Pattern.compile("implementation\\s+\"org\\.sensorhub:sensorhub-core:\\$\\{oshCoreVersion}\"")
                .matcher(buildGradle).find(), "sensorhub-core must be on the Java implementation classpath");
        assertTrue(Pattern.compile("implementation\\s+\"org\\.sensorhub:sensorhub-service-consys:\\$\\{oshCoreVersion}\"")
                .matcher(buildGradle).find(), "sensorhub-service-consys must be on the Java implementation classpath");
        assertTrue(Pattern.compile("implementation\\s+\"io\\.mavsdk:mavsdk:\\$\\{mavsdkVersion}\"")
                .matcher(buildGradle).find(), "mavsdk must be on the Java implementation classpath");
        assertTrue(buildGradle.contains("oshCoreVersion = '2.0.1'"), "OSH version must match upstream stable release");
        assertTrue(buildGradle.contains("mavsdkVersion = '3.14.0'"), "MAVSDK version must match upstream stable release");
        assertFalse(buildGradle.contains("driverBundle \"org.sensorhub:sensorhub-core"),
                "OSH dependencies must not be declared only on a custom driverBundle configuration");
    }

    @Test
    void scenarioFatJarPackagesRuntimeClasspathWithShadowPlugin() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(buildGradle.contains("id 'com.github.johnrengelman.shadow'"),
                "Shadow plugin must be applied for fat jar packaging");
        assertTrue(buildGradle.contains("archiveClassifier.set('all')"),
                "Shadow jar must produce an all-classifier fat jar");
        assertTrue(buildGradle.contains("configurations = [project.configurations.runtimeClasspath]"),
                "Shadow jar must include the Java runtime classpath");
        assertTrue(buildGradle.contains("tasks.named('build')"), "build task must depend on the fat jar");
        assertTrue(buildGradle.contains("configuration.setExtendsFrom([])"),
                "Structural tests must not inherit private production implementation artifacts");
        assertTrue(buildGradle.contains("compileClasspath = configurations.testCompileClasspath"),
                "Structural tests must not need private implementation artifacts on their compile classpath");
        assertTrue(buildGradle.contains("runtimeClasspath = output + configurations.testRuntimeClasspath"),
                "Structural tests must still run with their JUnit runtime engine");
    }

    @Test
    void scenarioOshRepositoryRemovalFailsCleanlyWithMissingRepositoryMessage() throws IOException, InterruptedException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertFalse(buildGradle.contains("verifyOshRepositoryAccess"),
                "No custom repository access task may contact the private OSH repository before dependency resolution");
        assertFalse(buildGradle.contains("beforeResolve"),
                "Resolvable configurations must not throw a custom error before Gradle resolves dependencies");
        assertFalse(buildGradle.contains("gpr.user") || buildGradle.contains("gpr.key"),
                "Normal dependency resolution must not require Gradle properties for a pre-resolution credential guard");
        assertTrue(buildGradle.contains("tasks.register('verifyOshRepositoryConfigured')"),
                "A scenario task must exist to fail cleanly when the OSH repository is removed");
        assertTrue(buildGradle.contains("verifyOshCredentialsForRuntimeResolution()"),
                "Build/shadowJar must have an executable clean-failure path for missing OSH credentials");

        Path tempProject = Files.createTempDirectory("osh-repository-removal-");
        Files.writeString(tempProject.resolve("settings.gradle"), "rootProject.name = 'osh-repository-removal'\n");
        Files.writeString(tempProject.resolve("build.gradle"), removeOshRepositoryBlock(buildGradle));

        GradleResult result = runGradle(tempProject.resolve("build.gradle"), "verifyOshRepositoryConfigured");

        assertEquals(1, result.exitCode(), "Gradle must fail when the OSH repository block is removed");
        assertTrue(result.output().contains("Missing required OpenSensorHub (OSH) Maven repository"),
                "Failure must clearly identify the missing OSH repository");
        assertTrue(result.output().contains("https://maven.pkg.github.com/opensensorhub/osh-core"),
                "Failure must name the required OSH repository URL");
        assertTrue(result.output().contains("org.sensorhub:sensorhub-core"),
                "Failure must explain which OSH dependency needs the repository");
    }

    @Test
    void scenarioOshRepositoryVerificationTaskPassesWhenRepositoryIsConfigured() throws IOException, InterruptedException {
        GradleResult result = runGradle(BUILD_GRADLE, "verifyOshRepositoryConfigured");

        assertEquals(0, result.exitCode(), "The configured build must pass the OSH repository verification task");
    }

    @Test
    void scenarioBuildFailsCleanlyWhenOshGitHubPackagesCredentialsAreMissing() throws IOException, InterruptedException {
        GradleResult result = runGradleWithoutGithubCredentials(BUILD_GRADLE, "build");

        assertEquals(1, result.exitCode(), "Build must fail cleanly before Shadow resolves private OSH artifacts without credentials");
        assertTrue(result.output().contains("OpenSensorHub (OSH) dependencies resolve from GitHub Packages"),
                "Failure must identify that OSH dependencies require GitHub Packages access");
        assertTrue(result.output().contains("GITHUB_ACTOR") && result.output().contains("GITHUB_TOKEN"),
                "Failure must name the environment variables needed for repository credentials");
        assertTrue(result.output().contains("read:packages"),
                "Failure must state the required GitHub Packages permission");
        assertTrue(result.output().contains("org.sensorhub:sensorhub-core"),
                "Failure must identify the dependency that cannot be resolved anonymously");
        assertFalse(result.output().contains("Received status code 401"),
                "Build should not fall through to Gradle's unactionable 401 dependency-resolution failure");
    }

    private static GradleResult runGradle(Path buildFile, String task) throws IOException, InterruptedException {
        ProcessBuilder processBuilder = new ProcessBuilder("./gradlew", "--no-daemon", "--quiet", "-b", buildFile.toString(), task)
                .redirectErrorStream(true);
        Process process = processBuilder.start();

        boolean finished = process.waitFor(Duration.ofSeconds(90).toMillis(), java.util.concurrent.TimeUnit.MILLISECONDS);
        String output = readProcessOutput(process.getInputStream());
        if (!finished) {
            process.destroyForcibly();
            throw new AssertionError("Gradle invocation timed out. Output so far:\n" + output);
        }

        return new GradleResult(process.exitValue(), output);
    }

    private static GradleResult runGradleWithoutGithubCredentials(Path buildFile, String task)
            throws IOException, InterruptedException {
        ProcessBuilder processBuilder = new ProcessBuilder("./gradlew", "--no-daemon", "--quiet", "-b", buildFile.toString(), task)
                .redirectErrorStream(true);
        processBuilder.environment().remove("GITHUB_ACTOR");
        processBuilder.environment().remove("GITHUB_TOKEN");
        Process process = processBuilder.start();

        boolean finished = process.waitFor(Duration.ofSeconds(90).toMillis(), java.util.concurrent.TimeUnit.MILLISECONDS);
        String output = readProcessOutput(process.getInputStream());
        if (!finished) {
            process.destroyForcibly();
            throw new AssertionError("Gradle invocation timed out. Output so far:\n" + output);
        }

        return new GradleResult(process.exitValue(), output);
    }

    private static String readProcessOutput(InputStream inputStream) throws IOException {
        try (inputStream) {
            return new String(inputStream.readAllBytes());
        }
    }

    private static String removeOshRepositoryBlock(String buildGradle) {
        List<String> lines = new ArrayList<>(List.of(buildGradle.split("\\R", -1)));
        int start = findOshRepositoryBlockStart(lines);
        int end = findBlockEnd(lines, start);
        lines.subList(start, end + 1).clear();
        return String.join(System.lineSeparator(), lines);
    }

    private static int findOshRepositoryBlockStart(List<String> lines) {
        for (int index = 0; index < lines.size(); index++) {
            if (!lines.get(index).trim().equals("maven {")) {
                continue;
            }

            int end = findBlockEnd(lines, index);
            String block = String.join("\n", lines.subList(index, end + 1));
            if (block.contains("oshRepositoryName") || block.contains("oshRepositoryUrl")) {
                return index;
            }
        }

        throw new IllegalStateException("Unable to find OSH repository block in build.gradle");
    }

    private static int findBlockEnd(List<String> lines, int start) {
        int depth = 0;
        for (int index = start; index < lines.size(); index++) {
            depth += count(lines.get(index), '{');
            depth -= count(lines.get(index), '}');
            if (depth == 0) {
                return index;
            }
        }

        throw new IllegalStateException("Unable to find end of block in build.gradle");
    }

    private static int count(String value, char needle) {
        int matches = 0;
        for (int index = 0; index < value.length(); index++) {
            if (value.charAt(index) == needle) {
                matches++;
            }
        }
        return matches;
    }

    private record GradleResult(int exitCode, String output) {
    }

    @Test
    void scenarioMavsdkSmokeHarnessEvidenceAnchorsAreTraceable() {
        // Requirement trace: mavlink.px4-sitl.mavsdk-smoke uses the qa-runner-provided
        // px4io/px4-sitl service on MAVLink UDP port 14540. Integration tests that
        // exercise MAVSDK control/telemetry must wait for HEARTBEAT frames and the
        // mavsdk_core_connected readiness signal before invoking action plugins.
        String evidenceAnchors = String.join("|",
                "mavlink.px4-sitl.mavsdk-smoke",
                "px4io/px4-sitl",
                "14540",
                "mavsdk_core_connected",
                "HEARTBEAT");

        assertTrue(evidenceAnchors.contains("mavlink.px4-sitl.mavsdk-smoke"),
                "The selected MAVSDK smoke harness profile must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("px4io/px4-sitl"),
                "The PX4 SITL service image anchor must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("14540"),
                "The MAVLink UDP port anchor must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("mavsdk_core_connected"),
                "The MAVSDK connected readiness anchor must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("HEARTBEAT"),
                "The MAVLink heartbeat readiness anchor must be documented in modified tests");
    }
}
