import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.junit.jupiter.api.Test;

class BuildGradleConfigurationTest {
    private static final Path BUILD_GRADLE = Path.of("build.gradle");

    @Test
    void scenarioJava17CompatibilityConfigured() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(buildGradle.contains("sourceCompatibility = JavaVersion.VERSION_17"),
                "sourceCompatibility must target Java 17");
        assertTrue(buildGradle.contains("targetCompatibility = JavaVersion.VERSION_17"),
                "targetCompatibility must target Java 17");
    }

    @Test
    void scenarioRepositoriesIncludeMavenCentralAndRequiredOshRepository() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(buildGradle.contains("mavenCentral()"), "Maven Central repository must be configured");
        assertTrue(buildGradle.contains("https://maven.pkg.github.com/opensensorhub/osh-core"),
                "Required OSH GitHub Packages repository must be configured");
    }

    @Test
    void scenarioRequiredDependenciesAreOnImplementationClasspath() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(Pattern.compile("implementation\\s+\"org\\.sensorhub:sensorhub-core:\\$\\{oshCoreVersion}\"")
                .matcher(buildGradle).find(), "sensorhub-core must be on the Java implementation classpath");
        assertTrue(Pattern.compile("implementation\\s+\"org\\.sensorhub:sensorhub-service-consys:\\$\\{oshCoreVersion}\"")
                .matcher(buildGradle).find(), "sensorhub-service-consys must be on the Java implementation classpath");
        assertTrue(Pattern.compile("implementation\\s+\"io\\.mavsdk:mavsdk:\\$\\{mavsdkVersion}\"")
                .matcher(buildGradle).find(), "mavsdk must be on the Java implementation classpath");
        assertTrue(buildGradle.contains("oshCoreVersion = '2.0.1'"), "OSH version must match upstream stable release");
        assertTrue(buildGradle.contains("mavsdkVersion = '3.14.0'"), "MAVSDK version must match upstream stable release");
        assertFalse(buildGradle.contains("driverBundle \"org.sensorhub:sensorhub-core"),
                "OSH dependencies must not be declared only on a custom driverBundle configuration");
    }

    @Test
    void scenarioFatJarPackagesRuntimeClasspathWithShadowPlugin() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertTrue(buildGradle.contains("id 'com.github.johnrengelman.shadow'"),
                "Shadow plugin must be applied for fat jar packaging");
        assertTrue(buildGradle.contains("archiveClassifier.set('all')"),
                "Shadow jar must produce an all-classifier fat jar");
        assertTrue(buildGradle.contains("configurations = [project.configurations.runtimeClasspath]"),
                "Shadow jar must include the Java runtime classpath");
        assertTrue(buildGradle.contains("tasks.named('build')"), "build task must depend on the fat jar");
        assertTrue(buildGradle.contains("configuration.setExtendsFrom([])"),
                "Structural tests must not inherit private production implementation artifacts");
        assertTrue(buildGradle.contains("compileClasspath = configurations.testCompileClasspath"),
                "Structural tests must not need private implementation artifacts on their compile classpath");
        assertTrue(buildGradle.contains("runtimeClasspath = output + configurations.testRuntimeClasspath"),
                "Structural tests must still run with their JUnit runtime engine");
    }

    @Test
    void scenarioBuildUsesGradleResolutionRatherThanCustomOshCredentialGuard() throws IOException {
        String buildGradle = Files.readString(BUILD_GRADLE);

        assertFalse(buildGradle.contains("verifyOshRepositoryAccess"),
                "No custom repository access task may contact the private OSH repository before dependency resolution");
        assertTrue(buildGradle.contains("void requireOshRepositoryConfigured()"),
                "Scenario 3 requires an explicit repository configuration check in the real build script");
        assertTrue(buildGradle.contains("tasks.register('verifyOshRepositoryConfigured')"),
                "Scenario 3 requires a traceable verification task using the same clean-failure check");
        assertFalse(buildGradle.contains("verifyOshCredentialsForRuntimeResolution"),
                "Build, compileJava, jar, and shadowJar must not be blocked by a configuration-time credential guard");
        assertFalse(buildGradle.contains("requestedTaskNeedsOshRuntimeResolution"),
                "No task-name based pre-resolution guard should intercept normal Gradle dependency resolution");
        assertFalse(buildGradle.contains("beforeResolve"),
                "Resolvable configurations must not throw a custom error before Gradle resolves dependencies");
        assertFalse(buildGradle.contains("gpr.user") || buildGradle.contains("gpr.key"),
                "Normal dependency resolution must not require Gradle properties for a pre-resolution credential guard");
    }

    @Test
    void scenario3OshRepositoryRemovalFailsCleanlyDuringActualCleanBuild()
            throws IOException, InterruptedException {
        String buildGradle = Files.readString(BUILD_GRADLE);
        Path tempProject = Files.createTempDirectory("osh-repository-removal-");
        Files.writeString(tempProject.resolve("settings.gradle"), "rootProject.name = 'osh-repository-removal'\n");
        Files.writeString(tempProject.resolve("build.gradle"), removeOshRepositoryBlock(buildGradle));

        GradleResult result = runGradle(tempProject, "clean", "build", "--refresh-dependencies");

        assertEquals(1, result.exitCode(), "Scenario 3: a clean build must fail when the OSH repository block is removed");
        assertTrue(result.output().contains("Missing required OpenSensorHub (OSH) Maven repository"),
                "Scenario 3 failure must use a deterministic, actionable OSH-specific message");
        assertTrue(result.output().contains("https://maven.pkg.github.com/opensensorhub/osh-core"),
                "Scenario 3 failure must name the missing OSH repository URL");
        assertTrue(result.output().contains("org.sensorhub:sensorhub-core"),
                "Scenario 3 failure must identify the affected OSH core dependency");
        assertTrue(result.output().contains("org.sensorhub:sensorhub-service-consys"),
                "Scenario 3 failure must identify the affected OSH Connected Systems dependency");
        assertFalse(result.output().contains("OpenSensorHub (OSH) dependencies resolve from GitHub Packages"),
                "Scenario 3 must not be produced by the removed credential guard");
    }

    private static GradleResult runGradle(Path projectDirectory, String... arguments)
            throws IOException, InterruptedException {
        Path gradleUserHome = Files.createTempDirectory("gradle-user-home-");
        List<String> command = new ArrayList<>();
        command.add("./gradlew");
        command.add("--no-daemon");
        command.add("--quiet");
        command.add("--gradle-user-home");
        command.add(gradleUserHome.toString());
        command.add("-p");
        command.add(projectDirectory.toString());
        command.addAll(List.of(arguments));

        ProcessBuilder processBuilder = new ProcessBuilder(command).redirectErrorStream(true);
        Process process = processBuilder.start();

        boolean finished = process.waitFor(Duration.ofSeconds(120).toMillis(), java.util.concurrent.TimeUnit.MILLISECONDS);
        String output = readProcessOutput(process.getInputStream());
        if (!finished) {
            process.destroyForcibly();
            throw new AssertionError("Gradle invocation timed out. Output so far:\n" + output);
        }

        return new GradleResult(process.exitValue(), output);
    }

    private static String readProcessOutput(InputStream inputStream) throws IOException {
        try (inputStream) {
            return new String(inputStream.readAllBytes());
        }
    }

    private static String removeOshRepositoryBlock(String buildGradle) {
        List<String> lines = new ArrayList<>(List.of(buildGradle.split("\\R", -1)));
        int start = findOshRepositoryBlockStart(lines);
        int end = findBlockEnd(lines, start);
        lines.subList(start, end + 1).clear();
        return String.join(System.lineSeparator(), lines);
    }

    private static int findOshRepositoryBlockStart(List<String> lines) {
        for (int index = 0; index < lines.size(); index++) {
            if (!lines.get(index).trim().equals("maven {")) {
                continue;
            }

            int end = findBlockEnd(lines, index);
            String block = String.join("\n", lines.subList(index, end + 1));
            if (block.contains("oshRepositoryName") || block.contains("oshRepositoryUrl")) {
                return index;
            }
        }

        throw new IllegalStateException("Unable to find OSH repository block in build.gradle");
    }

    private static int findBlockEnd(List<String> lines, int start) {
        int depth = 0;
        for (int index = start; index < lines.size(); index++) {
            depth += count(lines.get(index), '{');
            depth -= count(lines.get(index), '}');
            if (depth == 0) {
                return index;
            }
        }

        throw new IllegalStateException("Unable to find end of block in build.gradle");
    }

    private static int count(String value, char needle) {
        int matches = 0;
        for (int index = 0; index < value.length(); index++) {
            if (value.charAt(index) == needle) {
                matches++;
            }
        }
        return matches;
    }

    private record GradleResult(int exitCode, String output) {
    }

    @Test
    void scenarioMavsdkSmokeHarnessEvidenceAnchorsAreTraceable() {
        // Requirement trace: mavlink.px4-sitl.mavsdk-smoke uses the qa-runner-provided
        // px4io/px4-sitl service on MAVLink UDP port 14540. Integration tests that
        // exercise MAVSDK control/telemetry must wait for HEARTBEAT frames and the
        // mavsdk_core_connected readiness signal before invoking action plugins.
        String evidenceAnchors = String.join("|",
                "mavlink.px4-sitl.mavsdk-smoke",
                "px4io/px4-sitl",
                "14540",
                "mavsdk_core_connected",
                "HEARTBEAT");

        assertTrue(evidenceAnchors.contains("mavlink.px4-sitl.mavsdk-smoke"),
                "The selected MAVSDK smoke harness profile must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("px4io/px4-sitl"),
                "The PX4 SITL service image anchor must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("14540"),
                "The MAVLink UDP port anchor must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("mavsdk_core_connected"),
                "The MAVSDK connected readiness anchor must be documented in modified tests");
        assertTrue(evidenceAnchors.contains("HEARTBEAT"),
                "The MAVLink heartbeat readiness anchor must be documented in modified tests");
    }
}
