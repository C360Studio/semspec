# OSH MAVSDK Driver

Driver for integrating [MAVLink](https://mavlink.io/) /
[MAVSDK](https://mavsdk.mavlink.io/) autopilot telemetry and control with
[OpenSensorHub](https://opensensorhub.org/) via the OGC Connected Systems
API.

## Build system

Gradle. OSH itself uses Gradle (`build.gradle`, `common.gradle`,
`release.gradle`); a Maven-based driver fixture would force the agent to
translate Gradle conventions to Maven, which doesn't reflect real OSH
driver development. Java 17, matching `osh-core`'s `sourceCompatibility`.

## Baseline (the prompt's starting point)

The upstream reference implementation lives at
`opensensorhub/osh-addons/sensors/robotics/sensorhub-driver-mavsdk`. The
`@mavlink-hard` Playwright spec instructs the agent to treat that addon
as the baseline — preserve its OSH sensor module patterns, MAVSDK Java
integration, mavsdk_server lifecycle, telemetry outputs, and control
inputs unless the architecture explicitly replaces them.

## Reference material

The driver implements OpenSensorHub's Connected Systems API on top of
MAVSDK Java. The agent reads upstream sources directly when the EPIC
overlay is active:

- OSH addons (includes the baseline MAVSDK driver): `/sources/github-com-opensensorhub-osh-addons`
- MAVSDK Java library: `/sources/github-com-mavlink-MAVSDK-Java`
- OSH core (Gradle multi-module): `/sources/github-com-opensensorhub-osh-core`
- OGC Connected Systems API spec: `/sources/github-com-opengeospatial-ogcapi-connected-systems`

When `/sources/` is not mounted, fall back to `web_search` +
`http_request` against the canonical GitHub raw URLs. Cite specific
values (a version, a class signature, a config snippet) in the
implementation; do not paste large blocks of upstream source.

## MAVSDK coverage matrix

The driver represents a MAVSDK vehicle as an OGC Connected Systems API
system. MAVSDK telemetry/state plugins become **DataStreams**, command
plugins become **ControlStreams**, and driver lifecycle, health, result,
or acknowledgement notifications become **SystemEvents**. Plugins marked
**deferred** are intentionally not exposed until the driver has an OSH
contract, safety model, and test fixture for the behavior.

| MAVSDK Java plugin | OGC CS API representation | Driver status and notes |
| --- | --- | --- |
| `Action` | `ControlStream` plus command-result `SystemEvent` | Supported control surface for arm, disarm, takeoff, land, return-to-launch, hold, reboot, shutdown, kill, and transition-style vehicle actions. |
| `Telemetry` | `DataStream` plus health/connectivity `SystemEvent` | Supported primary data source for position, attitude, velocity, battery, GPS, flight mode, landed state, arming state, health, and heartbeat-derived connection state. |
| `Core` | `SystemEvent` | Supported for connection/discovery state and component lifecycle events. |
| `Info` | `DataStream` | Supported for vehicle, flight-controller, product, and version metadata snapshots. |
| `Mission` | `ControlStream` plus progress `DataStream` and result `SystemEvent` | Supported for typed mission upload, start, pause, clear, and progress reporting when the autopilot exposes the MAVSDK mission service. |
| `MissionRaw` | `ControlStream` plus progress/result events | Supported fallback for MAVLink-native mission items that cannot be represented by the typed `Mission` API without losing fields. |
| `Geofence` | `ControlStream` plus result `SystemEvent` | Supported for uploading and clearing geofence definitions. |
| `Gimbal` | `ControlStream` plus attitude/status `DataStream` | Supported for gimbal orientation commands and observable gimbal state when reported by the vehicle. |
| `Camera` | `ControlStream`, media/status `DataStream`, and result `SystemEvent` | Supported for capture-mode, photo, video, zoom, storage, and camera-status operations exposed by MAVSDK. |
| `ManualControl` | `ControlStream` | Supported for bounded manual stick/setpoint commands; operators must enforce authorization and rate limits before publishing inputs. |
| `Offboard` | `ControlStream` plus setpoint/status `DataStream` | Supported for offboard-mode start/stop and typed setpoint publication. Use only when command timing can be maintained by the OSH deployment. |
| `Param` | `DataStream` and `ControlStream` | Supported for reading parameter values and writing authorized parameter changes. |
| `MavlinkDirect` | `DataStream`, `ControlStream`, or `SystemEvent` depending on decoded message | Supported as the generic MAVLink fallback for messages with no typed MAVSDK plugin mapping. Prefer typed plugins when they preserve all required fields. |
| `Calibration` | Deferred | Deferred because calibration workflows are long-running, vehicle-specific, and need operator interaction contracts before being exposed through CS API controls. |
| `FollowMe` | Deferred | Deferred until the driver defines identity, update-rate, and privacy constraints for the moving target source. |
| `Ftp` | Deferred | Deferred because filesystem access requires a separate authorization and path-safety model. |
| `LogFiles` | Deferred | Deferred until OSH has a bounded artifact-transfer contract for listing and downloading vehicle logs. |
| `Failure` | Deferred | Deferred to non-production test harnesses; it intentionally injects vehicle failures and must not be exposed by default. |
| `Shell` | Deferred | Deferred because remote shell access is privileged and outside the CS API sensor/control contract. |
| `ActionServer` | Deferred | Deferred because it implements an onboard command-server role rather than the ground-station driver role. |
| `MissionRawServer` | Deferred | Deferred because it implements an onboard mission-server role rather than the ground-station driver role. |
| `TelemetryServer` | Deferred | Deferred because it publishes onboard telemetry to peers rather than consuming vehicle telemetry into OSH. |
| `ParamServer` | Deferred | Deferred because it implements an onboard parameter-server role rather than the ground-station driver role. |
| `Mocap` | Deferred | Deferred until OSH defines a motion-capture input source and timing contract for external vision data. |
| `ServerUtility` | Deferred | Deferred because server-control utilities are operational concerns for `mavsdk_server`, not vehicle observations or commands. |
| `Transponder` | Deferred | Deferred until ADS-B/transponder observations have a CS API schema and fixture coverage. |
| `Tune` | Deferred | Deferred until audible notification commands have an operator-facing safety and nuisance-control policy. |

## MAVSDK architecture and raw MAVLink tradeoffs

The default driver path uses the typed MAVSDK Java plugins through the
gRPC `mavsdk_server` peer. This path is preferred for normal OSH
operation because MAVSDK owns autopilot discovery, command encoding,
result-code normalization, retries, and stream typing. The typed plugins
also provide stable Java value objects that map cleanly to CS API
DataStreams and ControlStreams, making schema evolution and authorization
reviews easier than handling every MAVLink message directly.

The typed path has limits. It only exposes the messages and fields modeled
by the MAVSDK plugin API, it depends on a running `mavsdk_server` process,
and it adds a gRPC hop between OSH and the MAVLink endpoint. That extra
process is useful for portability and plugin semantics, but it can hide
vendor-specific MAVLink extensions, delay access to newly introduced
messages, and make very low-level diagnostics harder. Typed command calls
should therefore be used when the MAVSDK plugin preserves the fields the
CS API needs and when its result semantics are sufficient for operator
feedback.

The generic MAVLink fallback uses `MavlinkDirect` or the driver's native
raw-frame parser to represent decoded messages as DataStreams,
ControlStreams, or SystemEvents according to the message role. Use this
path for messages that MAVSDK does not model, vendor dialect extensions,
field-level diagnostics, compatibility tests that must assert exact frame
contents, and safety interlocks that need the original MAVLink result or
ACK payload. The fallback should stay narrow: validate message IDs and
payload lengths, bound every parser loop, and document each raw message's
CS API schema before exposing it to operators.

Choose a raw MAVLink peer over the gRPC MAVSDK peer when the deployment
must connect directly to a UDP or serial MAVLink endpoint, when
`mavsdk_server` cannot be installed or supervised on the target host, when
latency or byte-for-byte frame visibility is more important than typed
plugin convenience, or when the required autopilot feature is available
only as MAVLink/dialect traffic. Choose the gRPC MAVSDK peer when the
operation is covered by a typed plugin, when command result normalization
matters, when multiple autopilot transports should look the same to OSH,
or when the profile needs MAVSDK health-gated action and telemetry
behavior such as the `mavlink.px4-sitl.mavsdk-smoke` harness.

## Building

```sh
./gradlew dependencies   # resolve declared deps (the structural-validator
                         # gradle-dependencies check)
./gradlew test           # compile + run JUnit 5 tests
```

The `build.gradle` ships with `repositories` and `dependencies` blocks
intentionally left as TODOs — those are the agent's first task,
informed by reading the upstream `sensorhub-driver-mavsdk/build.gradle`
and the OSH + MAVSDK release configurations.

## Harness profiles

The `mavlink.px4-sitl.mavsdk-smoke` profile in
`workflow/harnesscatalog/catalog/mavlink.yaml` provides a live PX4 SITL
+ mavsdk_server qa-runner service. The architect selects it for the
required smoke acceptance test; the raw `mavlink.raw-mavlink-direct`
compatibility profile covers the generic-MAVLink path.
